# Project Report & Documentation: Sonam Homestay Booking System

This documentation explains how the **Sonam Homestay** project is built, the technologies used, the database structure, and how we followed the **Waterfall Model** to build it. It is written in simple, easy-to-understand language, perfect for project submissions, presentations, or viva preparation.

---

## 1. The Waterfall Model (How We Built the Project)

The Waterfall Model is a classic software development method. It is a linear, step-by-step process where you finish one phase completely before moving to the next. You cannot go backwards, just like water flowing down a waterfall.

Here is how we applied each phase of the Waterfall Model to build Sonam Homestay:

```text
[1. Requirements] -> [2. System Design] -> [3. Coding] -> [4. Testing] -> [5. Deployment]
```

### Phase 1: Requirements Analysis (What does the system need?)
In this initial stage, we wrote down exactly what the homestay website should do:
- **The Core Rule:** We wanted a system where guests can register and book homestay rooms, but only **one single host** (owner) can register to manage all the listings.
- **Simplicity:** No complicated framework. We chose raw PHP (Core PHP) and simple MySQL so it is easy to read, edit, and present.
- **Features:** Guests should be able to search stays by location, input check-in/out dates, see prices, and make fake payments. The host should be able to approve or reject these bookings.

### Phase 2: System Design (Structuring the data and layouts)
Next, we planned how to organize the files and database:
- **Database Schema:** We created `sonamDB` with tables for users, owners, homestays, rooms, bookings, payments, and reviews. We linked tables together using foreign keys (for example, linking a room to a homestay, and a booking to a user).
- **Folder Organization:** We decided to group files into separate folders:
  - `authentication/` for login and registration.
  - `pages/` for guest search, detail pages, and payment checkout.
  - `user/` and `owner/` for their respective dashboard screens.
  - `config/` for database connections and sessions.
  - `includes/` for headers, footers, navbars, and helper functions.

### Phase 3: Coding & Implementation (Writing the code)
Once the design was ready, we started writing the code:
- **Database connection:** We set up PDO in `config/database.php` for safe database queries.
- **Layout components:** We wrote `header.php` and `footer.php` so we do not have to copy and paste the HTML structure on every page.
- **Frontend design:** We imported Bootstrap 5 for clean buttons and grids, Font Awesome for icons, and simple JavaScript for calculations.
- **Business Logic:** We wrote standard forms that submit using POST and GET methods to handle registrations, homestay additions, and bookings.

### Phase 4: Testing & Verification (Finding and fixing bugs)
After writing the code, we tested all possible workflows:
- **User sign-up:** Registered as a guest, then tried to register as a host. Verified that once one host is created, no one else can register as a host.
- **Date calculations:** Input check-in and check-out dates to confirm that the javascript and PHP calculate the nights and total price correctly.
- **Double booking protection:** Attempted to book the same room on the same dates to ensure the system blocks unavailable dates.
- **Payments:** Ran dummy transactions with fake card details to verify bookings transition to the "pending review" state and trigger alerts.

### Phase 5: Deployment & Maintenance
The final step is running the project locally. We deploy it using **XAMPP**:
1. Place the project folder in `C:\xampp\htdocs\HomeStay`.
2. Turn on Apache and MySQL in XAMPP control panel.
3. Open `http://localhost/HomeStay/database/install.php` to build the database automatically.
4. Open `http://localhost/HomeStay/` to browse the live site.

---

## 2. Software Requirements Specification (SRS) - Simplified

### 2.1 Product Perspective & Goal
Sonam Homestay is a local booking platform for travelers visiting Sikkim. It eliminates the middleman, allowing travelers to book rooms directly from a local family host.

### 2.2 User Types (Who uses it?)
1. **Guest (Traveler):**
   - Can register, search properties, select check-in/out dates, input guest numbers, see prices, and make mock payments.
   - Can view booking history and write review ratings.
2. **Host (Single Owner):**
   - Full control to add, edit, and delete homestay properties and rooms.
   - Can view reservation requests and accept or reject them.
   - Can view monthly earnings and reply to guest reviews.

### 2.3 Non-Functional Requirements (Performance & Security)
- **SQL Injection Prevention:** Every database query uses PDO prepared statements (placeholders `?` or `:names`) so hackers cannot inject malicious SQL commands.
- **XSS Prevention:** All text entered by users is escaped using `htmlspecialchars()` via a helper function `e()` before rendering, preventing script injections.
- **CSRF Protection:** Forms submit a hidden random token checked on the server side to verify the request was sent by the actual user.
- **Responsive Layout:** The design automatically resizes for desktop, tablet, and mobile screens.

---

## 3. Database Schema & Tables (Data Dictionary)

The database is called `sonamDB`. It has 11 tables. Here is a simple explanation of what each table does and how they connect:

1. **`users`**: Contains account details for both guests and the owner (name, email, phone, and hashed password).
2. **`owners`**: Links to `users` table. It stores business details like business name and bank details for the single host.
3. **`homestays`**: Stores properties added by the host (name, location, description, cover image). It links to `owners`.
4. **`rooms`**: Stores individual rooms inside a homestay (price per night, beds, bathrooms, max guests). It links to `homestays`.
5. **`bookings`**: Stores reservations made by guests (check-in/out dates, contact details, total price, status). It links to `users` and `homestays`.
6. **`booking_details`**: Captures a snapshot of the room details and nightly price at the moment of booking (so changing room prices later won't affect old bookings). Links to `bookings` and `rooms`.
7. **`payments`**: Records mock payments. It stores transaction IDs, amounts, and payment methods (Card/UPI). Links to `bookings`.
8. **`reviews`**: Holds rating stars (1 to 5) and written feedback comments submitted by guests. Links to `users` and `homestays`.
9. **`notifications`**: Stores logs and inbox alerts (e.g. "New booking received"). Links to `users`.
10. **`wishlist`**: Stores properties saved by guests for future travel. Links to `users` and `homestays`.
11. **`password_resets`**: Stores temporary tokens for password recovery.

---

## 4. Code Architecture Walkthrough (How the files work)

Here is a simple walk-through of the main files to explain how the backend works:

### A. Configuration & Connections
- **[constants.php](file:///c:/xampp/htdocs/HomeStay/config/constants.php)**: The main settings file. It defines the database name (`sonamDB`), base URL, upload folder paths, and timezones.
- **[database.php](file:///c:/xampp/htdocs/HomeStay/config/database.php)**: Establishes a PDO connection. If the database does not exist, it automatically redirects the user to the setup installer (`database/install.php`).
- **[session.php](file:///c:/xampp/htdocs/HomeStay/config/session.php)**: Starts the session. It creates CSRF protection tokens, defines check functions (`is_logged_in()`, `is_owner()`), and handles flash notifications.

### B. Shared Layouts & Functions
- **[functions.php](file:///c:/xampp/htdocs/HomeStay/includes/functions.php)**: Holds reusable utility code. 
  - `e($text)`: Safely escapes text to prevent XSS.
  - `money($amount)`: Formats numbers into currency text (e.g. ₹1,200.00).
  - `is_room_available($roomId, $checkIn, $checkOut)`: Queries the database to make sure a room doesn't have overlapping bookings on selected dates.
- **[header.php](file:///c:/xampp/htdocs/HomeStay/includes/header.php)** & **[footer.php](file:///c:/xampp/htdocs/HomeStay/includes/footer.php)**: Standard structural layout files that wrap each page, loading CSS styles, theme variables, and javascript.

### C. Booking Workflow
1. **Browse**: Guests browse homestays on **[index.php](file:///c:/xampp/htdocs/HomeStay/index.php)** or search properties on **[search.php](file:///c:/xampp/htdocs/HomeStay/pages/search.php)**.
2. **Details**: Clicking a stay opens **[homestay-details.php](file:///c:/xampp/htdocs/HomeStay/pages/homestay-details.php)**. It loads room lists, cover photo carousels (Swiper JS), and verified reviews.
3. **Reservation Form**: **[book.php](file:///c:/xampp/htdocs/HomeStay/pages/book.php)** receives check-in and check-out dates. It computes subtotals, cleaning fees, and service fees in JavaScript (`main.js`) and validates them using secure server-side PHP.
4. **Mock Checkout**: **[payment.php](file:///c:/xampp/htdocs/HomeStay/pages/payment.php)** displays payment methods (Card/UPI). Submitting form values writes records into `bookings`, `booking_details`, and `payments` tables in a database transaction (`beginTransaction`), ensuring that if any query fails, all queries rollback.
5. **Notification**: The host dashboard is alerted of the pending booking request via the `notifications` system.
